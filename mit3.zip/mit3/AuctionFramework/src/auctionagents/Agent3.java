package auctionagents;

import auctionframework.AbstractAgent;
import auctionframework.Auction;
import auctionframework.AuctionItem;

/**
 *
 * @author 
 */
public class Agent3  extends AbstractAgent {

    /**
     * Default constructor of the third agent.
     * 
     * @param name          Generated name of the agent.
     * @param auction       The auction the agent participates in.
     * @param money         The money the agent has.
     */
    public Agent3(String name, Auction auction, int money) {
        super(name, auction, money);
    }

    /**
     * The return value of this function indicates if the agent bids for the 
     * actual item in the auction.
     * 
     * @param item          The item to bid for
     * @return              True if the agent bids for the current price.
     */
    @Override
    public boolean ask(AuctionItem item) {
        int startingPrice = item.getStartingPrice();
        int currentPrice = item.getPrice();

        // Maximum 120%-os határnál nem licitálunk többet
        int maxAllowedPrice = (int) (startingPrice * 1.2);
        if (currentPrice > maxAllowedPrice) {
            return false;
        }

        // Növeljük a kiszállási esélyt az áremelkedéssel arányosan
        double priceIncrease = ((double) currentPrice / startingPrice) - 1;
        double exitProbability = 0.3 + priceIncrease * 0.1;

        // Véletlenszerűen döntünk a kiszállásról a kiszállási esély alapján
        if (Math.random() < exitProbability) {
            return false;
        }

        // Ha eddig nem szálltunk ki, tartjuk a licitet
        return true;
    }
}
