package rescueagents;

import rescueframework.AbstractRobotControl;
import world.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  RobotControl class to implement custom robot control strategies
 */
public class RobotControl extends AbstractRobotControl{
    /**
     * Default constructor saving world robot object and percepcion
     * 
     * @param robot         The robot object in the world
     * @param percepcion    Percepcion of all robots
     */

    public static int ID_COUNTER = 0;
    public Map<Integer, Cell> reservedCells = new HashMap<>();
    private int id;
    public RobotControl(Robot robot, RobotPercepcion percepcion) {
        super(robot, percepcion);
        id = ID_COUNTER++;
    }
    
    
    /**
     * Custom step strategy of the robot, implement your robot control here!
     * 
     * @return  Return NULL for staying in place, 0 = step up, 1 = step right,
     *          2 = step down, 3 = step left
     */
    public Integer step() {

        Path pathToInjured = percepcion.getShortestInjuredPath(robot.getLocation());
        if (pathToInjured != null && !robot.hasInjured() && pathToInjured.getPath().size() <= 3) {
            Cell finalCell = pathToInjured.getPath().get(pathToInjured.getLength()-1);
            if (!this.isReserved(finalCell)) {
                reservedCells.put(id, finalCell);
                return pathToInjured.getFirstCell().directionFrom(robot.getLocation());
            }
        }
        if (robot.hasInjured()) {
            Path path = percepcion.getShortestExitPath(robot.getLocation());
            if (path != null) {
                return path.getFirstCell().directionFrom(robot.getLocation());
            }
        } else {
            Path path = percepcion.getShortestUnknownPath(robot.getLocation());
            if (path != null) {
                Cell finalCell = path.getPath().get(path.getLength()-1);
                if (!this.isReserved(finalCell)) {
                    reservedCells.put(id, finalCell);
                    return path.getFirstCell().directionFrom(robot.getLocation());
                }
            } else {
                List<Injured> injureds = percepcion.getDiscoveredInjureds();
                // Get injured with the lowest health
                if (injureds != null){
                    Injured lowestHealthInjured = injureds.getFirst();
                    int lowestHelath= Integer.MAX_VALUE;
                    for (Injured injured : injureds) {
                        if (injured.getHealth() > 0 && injured.getHealth() < lowestHelath && !this.isReserved(injured.getLocation())) {
                            lowestHealthInjured = injured;
                            lowestHelath = injured.getHealth();
                        }
                    }
                    ArrayList<Cell> targets = new ArrayList<>();
                    targets.add(lowestHealthInjured.getLocation());
                    Path injuredPath = percepcion.getShortestPath(robot.getLocation(), targets);
                    if (injuredPath != null) {
                        return injuredPath.getFirstCell().directionFrom(robot.getLocation());
                    }
                }
            }
        }
        return null;
    }

    boolean isReserved(Cell cell) {
        for (int i = 0; i < ID_COUNTER; i++) {
            if (i != id && reservedCells.containsKey(i) && reservedCells.get(i).equals(cell)) {
                return true;
            }
        }
        return false;
    }

}
